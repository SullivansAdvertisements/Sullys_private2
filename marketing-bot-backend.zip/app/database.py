# Database connection logic
