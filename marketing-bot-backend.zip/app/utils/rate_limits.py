# Rate limiting utilities
