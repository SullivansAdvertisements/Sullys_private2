# Budget allocation logic
